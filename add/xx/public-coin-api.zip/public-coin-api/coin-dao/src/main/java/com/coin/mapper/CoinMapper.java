package com.coin.mapper;

import com.coin.entity.Coin;

import java.util.List;

public interface CoinMapper {

    List<Coin> getCoins();

}
